//Openrevolution IDSP writer
//Copyright (C) 2021 I.C.

unsigned char brstm_formats_encode_idsp(Brstm* brstmi, signed int debugLevel, uint8_t encodeADPCM) {
    if(debugLevel >= 0) std::cout << "IDSP writing is not currently supported.\n";
    return 210;
}
