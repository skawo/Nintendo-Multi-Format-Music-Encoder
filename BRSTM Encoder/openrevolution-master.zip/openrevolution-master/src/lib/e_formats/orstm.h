//Open Revolution Stream encoder
//Copyright (C) 2020 IC

unsigned char brstm_formats_encode_orstm(Brstm* brstmi,signed int debugLevel,uint8_t encodeADPCM) {
    if(debugLevel >= 0) std::cout << "ORSTM is not implemented yet.\n";
    return 210;
}
