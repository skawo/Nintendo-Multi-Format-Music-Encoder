//Open Revolution Stream reader
//Copyright (C) 2020 IC

unsigned char brstm_formats_read_orstm(Brstm* brstmi,const unsigned char* fileData,signed int debugLevel,uint8_t decodeAudio) {
    if(debugLevel>=0) {std::cout << "ORSTM is not implemented yet.\n";}
    return 210;
}
